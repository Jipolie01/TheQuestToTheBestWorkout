<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <?php
    session_start();
            if (isset($_SESSION['informationChanged']) and $_SESSION['informationChanged'] == TRUE){
                    $message = "It worked. Your user information has been changed.";
                    print("<script type='text/javascript'>alert('$message');</script>");
                    $_SESSION['informationChanged'] = FALSE;
                }
                
if (!isset($_SESSION['username']) and !isset($_SESSION['informationChanged'])){
                header("Location: ./inloggen.html");
            }
                //$username = $_SESSION['username'];
                $id = $_SESSION['customerID'];
                
                //sql get username +user information
                $servername = "localhost";
                $usernamedb = "admin";
                $password = "geheim";
                $db = "customer_db";
                    
                // Create connection
                $conn = new mysqli($servername, $usernamedb, $password, $db);
                    
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
                else{
                    $sql = ("SELECT * FROM customerInfo WHERE customerID='$id'");//change to watever the table is with user information
                    $result = $conn->query($sql); 
                    
                    if(!empty($result)){
                        foreach ($result as $row){//Lots of changes needed to be done
                            $IBAN = $row['IBAN'];
                            $firstName = $row['name'];
                            $lastName = $row['surname'];
                            $phoneNumber = $row['cellphoneNumber'];
                            $gender = $row['gender'];
                            $weight = $row['weight'];
                        }
                    }
                    
                    $sql = ("SELECT * FROM addressInfo WHERE customerID='$id'");
                    $result = $conn->query($sql);
                    if(!empty($result)){
                        foreach ($result as $row){//Lots of changes needed to be done
                            $street = $row['street'];
                            $zipCode = $row['zipcode'];
                            $addressNumber = $row['addressNumber'];
                            $town = $row['town'];
                            $country = $row['country'];
                        }
                    }
                   $sql = ("SELECT * FROM loginInfo WHERE customerID='$id'");
                   $result = $conn->query($sql);
                    if(!empty($result)){
                        foreach ($result as $row){//Lots of changes needed to be done
                            $password = $row['password'];
                            $username = $row['email'];
                        }
                    }
                }
                $conn->close();
            
        ?>

	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Benno's Sportschool &mdash; De sportschool voor een gezonde levenstijl</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<!-- Google Webfonts -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Salvattore -->
	<link rel="stylesheet" href="css/salvattore.css">
	<!-- Theme Style -->
	<link rel="stylesheet" href="css/style.css">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<link rel="stylesheet" href="maininlog.css">
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-offcanvass">
			<a href="#" class="fh5co-offcanvass-close js-fh5co-offcanvass-close">Menu <i class="icon-cross"></i> </a>
			<h1 class="fh5co-logo"><a class="navbar-brand" href="index.html">Benno's Sportschool</a></h1>
			<ul>
				<li class="active"><a href="profile.html">Profielpagina</a></li>
                                <li><a href="performance.php">Performance</a></li>
                                <li><a href="pricing.html">Contact</a></li>
				<li><a href="index.html">Uitloggen</a></li>

			</ul>
		</div>
		<header id="fh5co-header" role="banner">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<a href="#" class="fh5co-menu-btn js-fh5co-menu-btn">Menu <i class="icon-menu"></i></a>
						<a class="navbar-brand" href="index.html">Benno's sportschool</a>		
					</div>
				</div>
			</div>
		</header>
		<!-- END .header -->	
       	
       	<div id="fh5co-main">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<center><h2>Uw profiel</h2></center>
					<div class="fh5co-spacer fh5co-spacer-sm"></div>
                                        <form action="changeInformation.php" method="post">
						<div class="row">
                                                    <div class="fh5co-desc">
                                                        <center>
                                                            IBAN:&nbsp;&nbsp;<input type="text" name="IBAN" style="width: 200px;" value='<?php print($IBAN); ?>'><br>
                                                            Naam:&nbsp;&nbsp;<input type="text" name="firstName" value='<?php print($firstName); ?>'><br>
                                                            Achternaam:&nbsp;&nbsp;<input type="text" name="lastName" value="<?php print($lastName) ?>"><br>
                                                            Adres:&nbsp;&nbsp;<input type="text" name="street" value="<?php print($street) ?>"><br>
                                                            Huisnummer:&nbsp;&nbsp;<input type="text" name="addressNumber" value="<?php print($addressNumber) ?>"><br>
                                                            Postcode:&nbsp;&nbsp;<input type="text" name="zipCode" value="<?php print($zipCode) ?>"><br>
                                                            Stad:&nbsp;&nbsp;<input type="text" name="town" value="<?php print($town) ?>"><br>
                                                            Land:&nbsp;&nbsp;<input type="text" name="country" value="<?php print($country) ?>"><br>
                                                            Telefoon nummer:&nbsp;&nbsp;<input type="text" name="phoneNumber" value="<?php print($phoneNumber) ?>"><br>
                                                            E-mail:&nbsp;&nbsp;<input type="text" name="email" value="<?php print($username) ?>"><br>
                                                            Wachtwoord:&nbsp;&nbsp;<input type="password" name="password" value="<?php print($password) ?>"><br>
                                                            Gewicht:&nbsp;&nbsp;<input type="text" name="weight" value="<?php print($weight) ?>"><br>
                                                            <?php
                                                            if ($gender == "Male"){
                                                                print('Gender:&nbsp;&nbsp;<input type="radio" name="gender" value="Male" checked> Male<br>');
                                                                print('&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Female"> Female<br>');
                                                            }
                                                            elseif ($gender == "Female"){
                                                                print('Gender&nbsp;&nbsp;<input type="radio" name="gender" value="Male"> Male<br>');
                                                                print('&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Female" checked> Female<br>');
                                                            }
                                                            else{
                                                                print('Gender&nbsp;&nbsp;<input type="radio" name="gender" value="Male"> Male<br>');
                                                                print('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Female"> Female<br>');
                                                            }
                                                            ?>
                                                        </center>
                                                        <input type="submit" value="Submit" style="left: 80%; top: 95%; position: absolute;">
                                                    </div>
		        		</div>
                                </form>
	       		</div>
			</div>
        </div>

		<footer id="fh5co-footer">
		
			<div class="container">
				<div class="row row-padded">
					<div class="col-md-12 text-center">
						<p class="fh5co-social-icons">
							<a href="#"><i class="icon-twitter"></i></a>
							<a href="#"><i class="icon-facebook"></i></a>
							<a href="#"><i class="icon-instagram"></i></a>
							<a href="#"><i class="icon-dribbble"></i></a>
							<a href="#"><i class="icon-youtube"></i></a>
						</p>
					</div>
				</div>
			</div>
		</div>
		</footer>


	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<!-- Salvattore -->
	<script src="js/salvattore.min.js"></script>
	<!-- Main JS -->
	<script src="js/main.js"></script>
	
	</body>
</html>
	
