<?php
session_start();
//if (!isset($_SESSION['username'])){
//                header("Location: index.php");
//}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    //do this when username password combination is correct
    $email = $_POST['email'];
    
    $servername = "localhost";
    $username = "admin";
    $password = "geheim";
    $db = "customer_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $db);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    
    else { 
        $sql = ("SELECT * FROM loginInfo");//Where username='$email'
        $result = $conn->query($sql);
        
        if (!empty($result)){
            foreach ($result as $row){
                if ($row['email'] == $email && $row['password'] == $_POST['password']){
                    $_SESSION['username'] = $email;
                    $_SESSION['goneBack'] = FALSE;
                    $_SESSION['customerID'] = $row['customerID'];
                    //go to next page
                    header("Location: ./profile.php");
                    
                }
                //else{
                //    $_SESSION['goneBack'] = TRUE;
                //    //go back
                //    header("Location: ./index.php");
                //}
            }
        }
        elseif (empty($result) or !isset($_SESSION['username'])){
            $_SESSION['goneBack'] = TRUE;
            //go back
            header("Location: ./inloggen.html");
        }
    }
    $conn->close();
?>