<?php
session_start();
//if (isset($_SESSION['username'])){
//    header("Location: index.php");
//}
$IBAN = $_POST['IBAN'];
$username = $_POST['username'];//done
$firstName = $_POST['firstName'];//done
$lastName = $_POST['lastName'];//done
$street = $_POST['street'];//done
$addressNumber = $_POST['addressNumber'];//done
$zipCode = $_POST['zipCode'];//done
$town = $_POST['town'];//done
$country = $_POST['country'];//country
$phoneNumber = $_POST['phoneNumber'];//done
$email = $_POST['email'];//done
$password = $_POST['password'];//done
$weight = $_POST['weight'];
$gender = $_POST['gender'];//done

$id = $_SESSION['customerID'];

$servername = "localhost";
$usernamedb = "admin";
$passworddb = "geheim";
$db = "customer_db";


// Create connection
$conn = new mysqli($servername, $usernamedb, $passworddb, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

else{
    $sql = ("UPDATE customerInfo SET IBAN='$IBAN', surname='$lastName', name='$firstName', gender='$gender', cellphoneNumber='$phoneNumber', weight='$weight' WHERE customerID = '$id'");//change to watever the table is with user information
    $conn->query($sql);
    $sql = ("UPDATE addressInfo SET street='$street', zipcode='$zipCode', addressNumber='$addressNumber', town='$town', country='$country' WHERE customerID = '$id'");//change to watever the table is with user information
    $conn->query($sql);
    $sql = ("UPDATE loginInfo SET email='$email', password='$password' WHERE customerID = '$id'");//change to watever the table is with user information
    $conn->query($sql);
    $_SESSION['informationChanged'] = TRUE;
    
}
$conn->close();
if (!isset($_SESSION['informationChanged'])){
    $_SESSION['informationChanged'] = FALSE;
}
$_SESSION['username'] = $_POST['username'];
header("Location: profile.php");
?>