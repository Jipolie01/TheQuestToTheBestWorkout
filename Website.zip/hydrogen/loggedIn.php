<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
        <image src="Images/strongman.png" width="150" height="150" style="position: fixed; left: 25%;"><image src="Images/logo.png" width="487.5" height="150" style="position: fixed; left: 40%;"/>
        <div class="navigationBar">
            <h4>Menu</h4>
            <form action="navigation.php" method="post">
                <button type="submit" class="navigationButton" name="changeUserInformation" value="changeInfo">Change user information</button><?php for ($i = 1;$i<25;$i++){
                                                                                                                                                        print("<br>");
                                                                                                                                                           } ?>
                <center><button type="submit" name="exit" value="Logout" class="navigationButton">Logout</button></center>
            </form>
        </div>
        
        <div class="mainpage" id="pages">
            <?php 
            if (isset($_SESSION['informationChanged']) and $_SESSION['informationChanged'] == TRUE){
                    $message = "It worked. Your user information has been changed.";
                    print("<script type='text/javascript'>alert('$message');</script>");
                }
            elseif (isset($_SESSION['informationChanged']) and $_SESSION['informationChanged'] == FALSE){
                    $message = "Something went wrong. Please try again later";
                    print("<script type='text/javascript'>alert('$message');</script>");
                }
            ?>
            <form action="changeInformation.php" method="post">
                <div class="text">
                    <br>
                    First name:<br><br>
                    Last name:<br><br>
                    Adress:<br><br>
                    House number:<br><br>
                    Zipcode:<br><br>
                    Town:<br><br>
                    Country:<br><br>
                    Phone number:<br><br>
                    E-mail:<br><br>
                    Password:<br><br>
                    gender:
                </div>
                <div class="textboxesdiv">
                    <input type="text" name="firstName" value='<?php print($firstName); ?>' class="changeInformation" style="margin-top: 17px;"><br>
                    <input type="text" name="lastName" value="<?php print($lastName) ?>" class="changeInformation"><br>
                    <input type="text" name="street" value="<?php print($street) ?>" class="changeInformation"><br>
                    <input type="text" name="addressNumber" value="<?php print($addressNumber) ?>" class="changeInformation"><br>
                    <input type="text" name="zipCode" value="<?php print($zipCode) ?>" class="changeInformation"><br>
                    <input type="text" name="town" value="<?php print($town) ?>" class="changeInformation"><br>
                    <input type="text" name="country" value="<?php print($country) ?>" class="changeInformation"><br>
                    <input type="text" name="phoneNumber" value="<?php print($phoneNumber) ?>" class="changeInformation"><br>
                    <input type="text" name="email" value="<?php print($username) ?>" class="changeInformation"><br>
                    <input type="password" name="password" value="<?php print($password) ?>" class="changeInformation"><br>
                    <?php
                    if ($gender == "Male"){
                        print('<input type="radio" name="gender" value="Male" checked> Male<br>');
                        print('<input type="radio" name="gender" value="Female"> Female<br>');
                    }
                    elseif ($gender == "Female"){
                        print('<input type="radio" name="gender" value="Male"> Male<br>');
                        print('<input type="radio" name="gender" value="Female" checked> Female<br>');
                    }
                    else{
                        print('<input type="radio" name="gender" value="Male"> Male<br>');
                        print('<input type="radio" name="gender" value="Female"> Female<br>');
                    }
                    ?>
                </div>
                    <input type="submit" class="navigationButton" value="Submit" style="left: 70%; top: 70%; position: absolute;">
            </form>
        </div>
        
    </body>
</html>
<!--
target frames met buttons
en om de informatie uit de database te editen moet je value= gebruiken wat zorgt dat het de oude waarde in de textboxes komt
-->